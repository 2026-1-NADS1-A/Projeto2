﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System;
using System;
using System.Data.SQLite;
using System.Windows.Forms;

namespace PrototipoMessier
{
    public partial class PacoteForms : Form
    {
        private string connectionString = "Data Source=banco.db;Version=3;";

        public PacoteForms()
        {
            InitializeComponent();
            CriarTabelaPacotes(); // Garante que a tabela de pacotes exista ao abrir a tela
            CarregarPacotesDoBanco();
            PreencherListaDeJogos(); // Chama a função para trazer os jogos reais

            this.Activated += (s, e) => PreencherListaDeJogos();
        }

        private void CriarTabelaPacotes()
        {
            using (var conexao = new SQLiteConnection(connectionString))
            {
                conexao.Open();

                // Cria a tabela de pacotes se ela não existir
                string sql = @"CREATE TABLE IF NOT EXISTS Pacotes (
                            Id INTEGER PRIMARY KEY AUTOINCREMENT,
                            Nome TEXT NOT NULL,
                            Descricao TEXT
                          );";

                using (var comando = new SQLiteCommand(sql, conexao))
                {
                    comando.ExecuteNonQuery();
                }
            }
        }

        private void SalvarPacote(string nome, string descricao)
        {
            using (var conexao = new SQLiteConnection(connectionString))
            {
                conexao.Open();

                string sql = "INSERT INTO Pacotes (Nome, Descricao) VALUES (@Nome, @Descricao);";

                using (var comando = new SQLiteCommand(sql, conexao))
                {
                    comando.Parameters.AddWithValue("@Nome", nome);
                    comando.Parameters.AddWithValue("@Descricao", descricao);

                    comando.ExecuteNonQuery();
                }
            }
            MessageBox.Show("Pacote salvo no banco de dados com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            // Salva o pacote no banco de dados SQLite
            SalvarPacote(txtNome.Text, "");

            // Limpa e recarrega a tabela visual puxando direto do banco
            CarregarPacotesDoBanco();
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            txtNome.Text = "";
            txtID.Text = "";
            for (int i = 0; i < checkedListBox1.Items.Count; i++)
            {
                checkedListBox1.SetItemCheckState(i, CheckState.Unchecked);
            }
        }

        private void CarregarPacotesDoBanco()
        {
            grdPacotes.Rows.Clear();

            using (var conexao = new SQLiteConnection(connectionString))
            {
                conexao.Open();

                string sql = "SELECT Id, Nome FROM Pacotes;";

                using (var comando = new SQLiteCommand(sql, conexao))
                {
                    using (var leitor = comando.ExecuteReader())
                    {
                        while (leitor.Read())
                        {
                            string id = leitor["Id"].ToString();
                            string nome = leitor["Nome"].ToString();

                            grdPacotes.Rows.Add(id, nome);
                        }
                    }
                }
            }
        }

        private void PreencherListaDeJogos()
        {
            // Limpa os itens fixos para receber os dados do banco
            checkedListBox1.Items.Clear();

            using (var conexao = new SQLiteConnection(connectionString))
            {
                conexao.Open();

                // Busca o Nome de todos os jogos cadastrados
                string sql = "SELECT Nome FROM Jogos;";

                using (var comando = new SQLiteCommand(sql, conexao))
                {
                    using (var leitor = comando.ExecuteReader())
                    {
                        while (leitor.Read())
                        {
                            string nomeJogo = leitor["Nome"].ToString();
                            checkedListBox1.Items.Add(nomeJogo);
                        }
                    }
                }
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            // Verifica se o usuário selecionou alguma linha na tabela de pacotes
            if (grdPacotes.CurrentRow != null && grdPacotes.CurrentRow.Cells[0].Value != null)
            {
                // Pega o ID do pacote selecionado
                string idSelecionado = grdPacotes.CurrentRow.Cells[0].Value.ToString();

                // Pede confirmação para evitar acidentes
                DialogResult confirmacao = MessageBox.Show("Tem certeza que deseja excluir este pacote?", "Confirmar Exclusão", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (confirmacao == DialogResult.Yes)
                {
                    // Deleta do banco
                    DeletarPacote(idSelecionado);

                    // Atualiza a tabela na tela na hora
                    CarregarPacotesDoBanco();
                }
            }
            else
            {
                MessageBox.Show("Por favor, selecione um pacote na tabela primeiro para conseguir excluir.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void DeletarPacote(string id)
        {
            using (var conexao = new SQLiteConnection(connectionString))
            {
                conexao.Open();

                // Comando SQL para deletar o pacote pelo ID
                string sql = "DELETE FROM Pacotes WHERE Id = @Id;";

                using (var comando = new SQLiteCommand(sql, conexao))
                {
                    comando.Parameters.AddWithValue("@Id", id);
                    comando.ExecuteNonQuery();
                }
            }
            MessageBox.Show("Pacote excluído com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}