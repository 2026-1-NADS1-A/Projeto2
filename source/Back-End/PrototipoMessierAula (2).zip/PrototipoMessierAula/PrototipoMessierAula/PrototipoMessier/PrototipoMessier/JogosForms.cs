﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System;
using System.Data.SQLite;
using System.Windows.Forms;

namespace PrototipoMessier
{
    public partial class JogosForms : Form
    {
        
        private string connectionString = "Data Source=banco.db;Version=3;";

        public JogosForms()
        {
            InitializeComponent();
            this.TopLevel = false;
            this.FormBorderStyle = FormBorderStyle.None;
            CriarBancoETabela(); 
            CarregarJogosDoBanco();
        }

        private void CriarBancoETabela()
        {
            using (var conexao = new SQLiteConnection(connectionString))
            {
                conexao.Open();

                // Cria a tabela de jogos se ela não existir
                string sql = @"CREATE TABLE IF NOT EXISTS Jogos (
                            Id INTEGER PRIMARY KEY AUTOINCREMENT,
                            Nome TEXT NOT NULL,
                            Genero TEXT,
                            Preco REAL
                          );";

                using (var comando = new SQLiteCommand(sql, conexao))
                {
                    comando.ExecuteNonQuery();
                }
            }
        }

        private void SalvarJogo(string nome, string descricao, string ativo)
        {
            using (var conexao = new SQLiteConnection(connectionString))
            {
                conexao.Open();

                
                string sql = "INSERT INTO Jogos (Nome, Genero, Preco) VALUES (@Nome, @Descricao, @Ativo);";

                using (var comando = new SQLiteCommand(sql, conexao))
                {
                    comando.Parameters.AddWithValue("@Nome", nome);
                    
                    comando.Parameters.AddWithValue("@Descricao", descricao);
                    comando.Parameters.AddWithValue("@Ativo", ativo);

                    comando.ExecuteNonQuery();
                }
            }
            MessageBox.Show("Jogo salvo no banco de dados com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            txtID.Text = "";
            txtNome.Text = "";
            txtDescricao.Text = "";
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            string Ativo = "NÃO";
            if (chkAtivo.Checked)
            {
                Ativo = "SIM";
            }

            // Salva no banco de dados SQLite
            SalvarJogo(txtNome.Text, txtDescricao.Text, Ativo);

            // Limpa a tabela da tela e recarrega tudo direto do banco (trazendo o ID real!)
            CarregarJogosDoBanco();
        }

        private void CarregarJogosDoBanco()
        {
            grdJogos.Rows.Clear();

            using (var conexao = new SQLiteConnection(connectionString))
            {
                conexao.Open();

                string sql = "SELECT Id, Nome, Genero, Preco FROM Jogos;";

                using (var comando = new SQLiteCommand(sql, conexao))
                {
                    using (var leitor = comando.ExecuteReader())
                    {
                        while (leitor.Read())
                        {
                            string id = leitor["Id"].ToString();
                            string nome = leitor["Nome"].ToString();
                            string descricao = leitor["Genero"].ToString();
                            string ativo = leitor["Preco"].ToString();

                            grdJogos.Rows.Add(id, nome, descricao, ativo);
                        }
                    }
                }
            }
        }

        private void DeletarJogo(string id)
        {
            using (var conexao = new SQLiteConnection(connectionString))
            {
                conexao.Open();

                // Deleta o registro baseado no ID único dele
                string sql = "DELETE FROM Jogos WHERE Id = @Id;";

                using (var comando = new SQLiteCommand(sql, conexao))
                {
                    comando.Parameters.AddWithValue("@Id", id);
                    comando.ExecuteNonQuery();
                }
            }
            MessageBox.Show("Jogo excluído com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void JogosForms_Load(object sender, EventArgs e)
        {

        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            // Verifica se o usuário selecionou alguma linha na tabela
            if (grdJogos.CurrentRow != null && grdJogos.CurrentRow.Cells[0].Value != null)
            {
                // Pega o valor da primeira coluna (ID) da linha selecionada
                string idSelecionado = grdJogos.CurrentRow.Cells[0].Value.ToString();

                // Pergunta para confirmar a ação
                DialogResult confirmacao = MessageBox.Show("Tem certeza que deseja excluir este jogo?", "Confirmar Exclusão", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (confirmacao == DialogResult.Yes)
                {
                    // Envia o ID para a função deletar do banco
                    DeletarJogo(idSelecionado);

                    // Atualiza a tabela na tela instantaneamente
                    CarregarJogosDoBanco();
                }
            }
            else
            {
                MessageBox.Show("Por favor, selecione um jogo válido na tabela primeiro para conseguir excluir.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void chkAtivo_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}