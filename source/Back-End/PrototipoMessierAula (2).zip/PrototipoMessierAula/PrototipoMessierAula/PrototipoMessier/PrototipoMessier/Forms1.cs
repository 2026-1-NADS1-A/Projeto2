using System;
using System.Windows.Forms;

namespace PrototipoMessier
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        // Faz o botão principal de Relatórios mostrar/esconder o sub-botão de Escolas
        private void btnRelatorios_Click(object sender, EventArgs e)
        {
            btnSubEscolas.Visible = !btnSubEscolas.Visible;
        }

        // Faz o sub-botão de Escolas abrir a sua tela RelEscolaForms dentro do painel
        private void btnSubEscolas_Click(object sender, EventArgs e)
        {
            panelConteudo.Controls.Clear();
            RelEscolaForms frmEscolas = new RelEscolaForms();
            frmEscolas.TopLevel = false;
            frmEscolas.FormBorderStyle = FormBorderStyle.None;
            frmEscolas.Dock = DockStyle.Fill;
            panelConteudo.Controls.Add(frmEscolas);
            frmEscolas.Show();
        }

        private void btnCadastros_Click(object sender, EventArgs e)
        {
            btnSubJogos.Visible = !btnSubJogos.Visible;
            btnSubPacotesForm.Visible = !btnSubPacotesForm.Visible;
        }

        // 2. Abre a tela de Jogos dentro do painel branco
        private void btnSubJogos_Click(object sender, EventArgs e)
        {
            MessageBox.Show("O botão certo está funcionando!");
            panelConteudo.Controls.Clear();
            JogosForms frmJogos = new JogosForms();
            frmJogos.TopLevel = false;
            frmJogos.FormBorderStyle = FormBorderStyle.None;
            frmJogos.Dock = DockStyle.Fill;
            panelConteudo.Controls.Add(frmJogos);
            frmJogos.Show();
        }

        // 3. Abre a tela de Pacotes dentro do painel branco
        private void btnSubPacotesForm_Click(object sender, EventArgs e)
        {
            panelConteudo.Controls.Clear();
            PacoteForms frmPacotes = new PacoteForms();
            frmPacotes.TopLevel = false;
            frmPacotes.FormBorderStyle = FormBorderStyle.None;
            frmPacotes.Dock = DockStyle.Fill;
            panelConteudo.Controls.Add(frmPacotes);
            frmPacotes.Show();
        }

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            panelConteudo = new Panel();
            panel1 = new Panel();
            pictureBox1 = new PictureBox();
            btnSubEscolas = new Button();
            btnRelatorios = new Button();
            btnSair = new Button();
            btnCadastros = new Button();
            btnSubPacotesForm = new Button();
            btnSubJogos = new Button();
            panel2 = new Panel();
            label1 = new Label();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panelConteudo
            // 
            panelConteudo.Dock = DockStyle.Fill;
            panelConteudo.Location = new Point(97, 63);
            panelConteudo.Name = "panelConteudo";
            panelConteudo.Size = new Size(646, 354);
            panelConteudo.TabIndex = 0;
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.Highlight;
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(btnSubEscolas);
            panel1.Controls.Add(btnRelatorios);
            panel1.Controls.Add(btnSair);
            panel1.Controls.Add(btnCadastros);
            panel1.Controls.Add(btnSubPacotesForm);
            panel1.Controls.Add(btnSubJogos);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(97, 417);
            panel1.TabIndex = 0;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(5, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(92, 60);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // btnSubEscolas
            // 
            btnSubEscolas.Location = new Point(10, 106);
            btnSubEscolas.Name = "btnSubEscolas";
            btnSubEscolas.Size = new Size(75, 23);
            btnSubEscolas.TabIndex = 2;
            btnSubEscolas.Text = "• Escolas";
            btnSubEscolas.UseVisualStyleBackColor = true;
            btnSubEscolas.Visible = false;
            btnSubEscolas.Click += btnSubEscolas_Click;
            // 
            // btnRelatorios
            // 
            btnRelatorios.Location = new Point(10, 77);
            btnRelatorios.Name = "btnRelatorios";
            btnRelatorios.Size = new Size(75, 23);
            btnRelatorios.TabIndex = 2;
            btnRelatorios.Text = "Relatórios";
            btnRelatorios.UseVisualStyleBackColor = true;
            btnRelatorios.Click += btnRelatorios_Click;
            // 
            // btnSair
            // 
            btnSair.Location = new Point(10, 382);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(75, 23);
            btnSair.TabIndex = 4;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // btnCadastros
            // 
            btnCadastros.Location = new Point(10, 168);
            btnCadastros.Name = "btnCadastros";
            btnCadastros.Size = new Size(75, 23);
            btnCadastros.TabIndex = 1;
            btnCadastros.Text = "Cadastros";
            btnCadastros.UseVisualStyleBackColor = true;
            btnCadastros.Click += btnCadastros_Click;
            // 
            // btnSubPacotesForm
            // 
            btnSubPacotesForm.Location = new Point(10, 226);
            btnSubPacotesForm.Name = "btnSubPacotesForm";
            btnSubPacotesForm.Size = new Size(75, 23);
            btnSubPacotesForm.TabIndex = 3;
            btnSubPacotesForm.Text = "• Pacotes";
            btnSubPacotesForm.UseVisualStyleBackColor = true;
            btnSubPacotesForm.Visible = false;
            btnSubPacotesForm.Click += btnSubPacotesForm_Click;
            // 
            // btnSubJogos
            // 
            btnSubJogos.Location = new Point(10, 197);
            btnSubJogos.Name = "btnSubJogos";
            btnSubJogos.Size = new Size(75, 23);
            btnSubJogos.TabIndex = 2;
            btnSubJogos.Text = "• Jogos";
            btnSubJogos.UseVisualStyleBackColor = true;
            btnSubJogos.Visible = false;
            btnSubJogos.Click += btnSubJogos_Click_1;
            // 
            // panel2
            // 
            panel2.BackColor = SystemColors.Highlight;
            panel2.Controls.Add(label1);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(97, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(646, 63);
            panel2.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Unispace", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(217, 22);
            label1.Name = "label1";
            label1.Size = new Size(130, 23);
            label1.TabIndex = 2;
            label1.Text = "MessierApp";
            label1.Click += label1_Click;
            // 
            // Form1
            // 
            ClientSize = new Size(743, 417);
            Controls.Add(panelConteudo);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Name = "Form1";
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);

        }

        // 4. Botão Sair
        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private Panel panelConteudo;
        private Button btnSair;
        private Button btnSubPacotesForm;
        private Button btnSubJogos;
        private Button btnCadastros;
        private Panel panel2;
        private Label label1;
        private Button btnSubEscolas;
        private Button btnRelatorios;
        private PictureBox pictureBox1;
        private Panel panel1;

        private void btnSubJogos_Click_1(object sender, EventArgs e)
        {
            panelConteudo.Controls.Clear();

            JogosForms frmJogos = new JogosForms();
            frmJogos.TopLevel = false;
            frmJogos.FormBorderStyle = FormBorderStyle.None;
            frmJogos.Dock = DockStyle.Fill;

            panelConteudo.Controls.Add(frmJogos);
            frmJogos.Show();
        }
    }
}