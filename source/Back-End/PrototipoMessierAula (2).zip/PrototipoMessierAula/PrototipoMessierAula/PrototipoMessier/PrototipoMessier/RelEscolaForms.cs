﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrototipoMessier
{
    public partial class RelEscolaForms : Form
    {
        public RelEscolaForms()
        {
            InitializeComponent();
        }

        private void btnImprimir_Click(object sender, EventArgs e)
        {
                txtRelatorio.Text = "| ESCOLA               | PACOTE \r\n";
            for (int i = 1; i < 10; i++)
            {
                txtRelatorio.Text += "| ESCOLA   " + i + "          |" + i + "\r\n";
            }
        }
    }
}
